import pygame,sys,random
from pygame.locals import *

def main_game(bird_frames):
	def create_pipe():
		random_pipe_pos = random.choice(pipe_heigth)
		bottom_pipe = pipe_surface.get_rect(midtop = (1100,random_pipe_pos))
		top_pipe = pipe_surface.get_rect(midbottom = (1100,random_pipe_pos - 250))
		return top_pipe,bottom_pipe

	def move_pipes(pipes):
		for pipe in pipes:
			pipe.centerx -= 2.5
		return pipes

	def draw_pipes(pipes):
		for pipe in pipes:
			if pipe.bottom >= 650:
				if theme_duration < 20:
					screen.blit(pipe_surface,pipe)
				if theme_duration >= 20:
					screen.blit(pipe_surface2,pipe)
			
			else:
				if theme_duration < 20:
					flip_pipe = pygame.transform.flip(pipe_surface,False,True)
				if theme_duration >= 20:
					flip_pipe = pygame.transform.flip(pipe_surface2,False,True)
				screen.blit(flip_pipe,pipe)

	def check_collision(pipes):
		for pipe in pipes:
			if bird_rect.colliderect(pipe):
				death_sound.play()
				return False
		if bird_rect.top <= -100 or bird_rect.bottom >= 800:
			death_sound.play()
			return False
		return True

	def create_coin():
		random_coin_pos = random.choice(coin_height)
		new_coin = coin_surface.get_rect(midtop = (1300,random_coin_pos))
		return new_coin

	def move_coins(coins):
		for coin in coins:
			coin.centerx -= 6
		return coins

	def draw_coins(coins):
		for coin in coins:
			screen.blit(coin_surface,coin)
		
	def coin_collision(coins):
		for coin in coins:
			if bird_rect.colliderect(coin):
				coin_sound.play()
				return False
		return True

	def create_enemy_bird():
		random_enemy_bird_pos = random.choice(enemy_bird_height)
		new_enemy_bird = enemy_bird.get_rect(midtop = (1300,random_enemy_bird_pos))
		return new_enemy_bird

	def move_enemy_birds(enemy_birds):
		for enemybird in enemy_birds:
			enemybird.centerx -= 15
		return enemy_birds

	def draw_enemy_birds(enemy_birds):
		for enemybird in enemy_birds:
			screen.blit(enemy_bird, enemybird)
		
	def enemy_bird_collision(enemy_birds):
		for enemybird in enemy_birds:
			if bird_rect.colliderect(enemybird):
				enemy_bird_sound.play()
				return False
		return True

	def draw_health():
		pygame.draw.rect(screen, (255,0,0), (health_x, health_y, health_width_red, health_height))
		pygame.draw.rect(screen, (255,255,0), (health_x, health_y, health_width_yellow, health_height))


	def rotate_bird(bird):
		new_bird = pygame.transform.rotozoom(bird, -bird_movement * 3, 1)
		return new_bird

	def bird_animation():
		new_bird = bird_frames[bird_index]
		new_bird_rect = new_bird.get_rect(center = (200,bird_rect.centery))
		return new_bird,new_bird_rect

	def score_pipe(pipes):
		score1 = 0
		theme_duration = 0
		for pipe in pipes:
			pipe.centerx -= 2.5
			if 95 < pipe.topleft[0] <= 100:
				score1 += 0.5
				theme_duration += 0.5
				return score1,theme_duration
		return 0,0


	def score_display(game_state):
		if game_state == 'main_game':
			score_surface = game_font.render(str(int(score)),True,(255,255,0))
			score_rect = score_surface.get_rect(center = (500,100))
			screen.blit(score_surface,score_rect)
			draw_health()
			year_surface = game_font.render(f'Year: {year}', True, (255, 255, 0))
			screen.blit(year_surface, (20, 82))

		if game_state == 'game_over':
			score_surface = game_font.render(f'Score: {str(int(score))}',True,(255,255,0))
			score_rect = score_surface.get_rect(center = (100,600))
			screen.blit(score_surface,score_rect)

			high_score_surface = game_font.render(f'High Score: {str(int(high_score))}',True,(255,255,0))
			high_score_rect = high_score_surface.get_rect(center = (800,600))
			screen.blit(high_score_surface,high_score_rect)

			rank_surface = game_font.render(f'Rank: {rank}', True, (255,255,0))
			screen.blit(rank_surface, (20, 20))

	def update_score(score,high_score):
		if score > high_score:
			high_score = score
		return high_score


	pygame.init()
	screen = pygame.display.set_mode((1000,650))             #screen for the game
	pygame.display.set_caption('FLAPPY BIRDS')
	icon = pygame.image.load('assets/icon.png')
	pygame.display.set_icon(icon)
	game_font = pygame.font.Font('04B_19.TTF',40)
	clock = pygame.time.Clock()


	#GAME VARIABLES
	gravity = 0.25
	bird_movement = 0
	game_active = True
	coin_collide = True
	enemy_bird_collide = True
	score = 0
	high_score = 0
	rank = ''
	health_width_red = 300
	health_width_yellow = 300
	health_height = 20
	health_x = 650
	health_y = 87
	year = 1
	theme_duration = 0

	#background
	bg_surface1 = pygame.image.load('assets/spring.png').convert()
	bg_surface2 = pygame.image.load("assets/summer.png").convert()
	bg_surface3 = pygame.image.load("assets/autumn.png").convert()
	bg_surface4 = pygame.image.load("assets/winter.png").convert()

	#bird
	bird_index = 0
	bird_surface = bird_frames[bird_index]
	bird_rect = bird_surface.get_rect(center = (200,325))

	BIRDFLAP = pygame.USEREVENT + 1
	pygame.time.set_timer(BIRDFLAP,30)

	#pipes
	pipe_surface = pygame.transform.scale2x(pygame.image.load('assets/pipe-green.png'))
	pipe_surface2 = pygame.transform.scale2x(pygame.image.load("assets/pipe-red.png"))
	pipe_list = []
	pipe_heigth = [300,350,400,500,600]
	SPAWNPIPE = pygame.USEREVENT
	pygame.time.set_timer(SPAWNPIPE,1200)

	#coin
	coin_surface = pygame.transform.scale2x(pygame.image.load('assets/coin.png').convert_alpha())
	coin_list = []
	coin_height = [200,350,400,500]
	SPAWNCOIN = pygame.USEREVENT + 2
	pygame.time.set_timer(SPAWNCOIN,1800)

	#enemy birds
	enemy_bird = pygame.transform.scale(pygame.image.load('assets/enemybird.png').convert_alpha(), (200,70))
	enemy_bird_list = []
	enemy_bird_height = [150,200,350,400,500,550]
	SPAWNENEMYBIRD = pygame.USEREVENT + 3
	pygame.time.set_timer(SPAWNENEMYBIRD,1800)

	#game over
	game_over_surface = pygame.transform.scale2x(pygame.image.load('assets/message.png').convert_alpha())
	game_over_rect = game_over_surface.get_rect(center = (500,325))

	#audio
	death_sound = pygame.mixer.Sound('audio/hit.wav')
	flap_sound = pygame.mixer.Sound('audio/wing.wav')
	coin_sound = pygame.mixer.Sound('audio/point.wav')
	enemy_bird_sound = pygame.mixer.Sound('audio/enemybirdcollide.mp3')
	
	pygame.mixer.music.load('audio/bgmusic.mp3')
	pygame.mixer.music.play(-1)

	while True:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_SPACE and game_active:
					bird_movement = 0
					bird_movement -= 7
					flap_sound.play()
				
				if event.key == pygame.K_SPACE and coin_collide == False:
					coin_collide = True
					score += 5
					theme_duration += 5
					coin_list.clear()

				if event.key == pygame.K_SPACE and enemy_bird_collide == False:
					enemy_bird_collide = True
					health_width_yellow -= 20
					enemy_bird_list.clear()
										
				if event.key == pygame.K_SPACE and game_active == False:
					game_active = True
					bird_movement = 0
					health_width_yellow = 300
					score = 0
					year = 1
					theme_duration = 0
					bird_rect.center = (200,325)
					pipe_list.clear()
					coin_list.clear()
					enemy_bird_list.clear()             

			if event.type == SPAWNPIPE:
				pipe_list.extend(create_pipe())
			
			if event.type == SPAWNCOIN:
				coin_list.append(create_coin())

			if event.type == SPAWNENEMYBIRD:
				if score > 20:
					enemy_bird_list.append(create_enemy_bird())
				

			if event.type == BIRDFLAP:
				if bird_index < 2:
					bird_index += 1
				else:
					bird_index = 0
				bird_surface,bird_rect = bird_animation()

		if theme_duration < 10:
			screen.blit(bg_surface1,(0,0))

		if theme_duration >= 10 and theme_duration < 20:
			screen.blit(bg_surface2,(0,0))
		
		if theme_duration >= 20 and theme_duration < 30:
			screen.blit(bg_surface3,(0,0))
		
		if theme_duration >= 30 and theme_duration < 40:
			screen.blit(bg_surface4,(0,0))
		
		if theme_duration >= 40:
			theme_duration = 0
			year += 1

		if health_width_yellow == 0:
			game_active = False

		if score <= 10:
			rank = 'Rookie'
		if score > 10 and score <=20:
			rank = 'Intermediate'
		if score > 20:
			rank = 'Expert'

		if game_active:      
			#BIRD
			bird_movement += gravity
			bird_rect.centery += bird_movement
			rotated_bird = rotate_bird(bird_surface)
			screen.blit(rotated_bird,bird_rect)
			game_active = check_collision(pipe_list)    

			#PIPES
			pipe_list = move_pipes(pipe_list)
			draw_pipes(pipe_list)
		
			#coins
			if coin_collide:
				coin_list = move_coins(coin_list)
				draw_coins(coin_list)
				coin_collide = coin_collision(coin_list)

			#enemy birds
			if enemy_bird_collide:
				if score > 20:
					enemy_bird_list = move_enemy_birds(enemy_bird_list)
					draw_enemy_birds(enemy_bird_list)
					enemy_bird_collide = enemy_bird_collision(enemy_bird_list)
                        

			pipe_score, pipe_theme_duration = score_pipe(pipe_list)
			score += pipe_score
			theme_duration += pipe_theme_duration
			score_display('main_game')
		else:
			screen.blit(game_over_surface,game_over_rect)
			high_score = update_score(score,high_score)
			score_display('game_over')

		clock.tick(120)
		pygame.display.update() 


pygame.init()

screen_width = 1000
screen_height = 650

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('FLAPPY BIRDS')
icon = pygame.image.load('assets/icon.png')
pygame.display.set_icon(icon)
font = pygame.font.SysFont('Constantia', 30)

#define colours
bg = pygame.image.load('assets/bg.png')
red = (255, 0, 0)
black = (0, 0, 0)
white = (255, 255, 255)
#blue bird
bluebird_downflap = pygame.transform.scale2x(pygame.image.load('assets/bluebird-downflap.png').convert_alpha())
bluebird_midflap = pygame.transform.scale2x(pygame.image.load('assets/bluebird-midflap.png').convert_alpha())
bluebird_upflap = pygame.transform.scale2x(pygame.image.load('assets/bluebird-upflap.png').convert_alpha())
bluebird_frames = [bluebird_downflap,bluebird_midflap,bluebird_upflap]

#red bird
redbird_downflap = pygame.transform.scale2x(pygame.image.load('assets/redbird-downflap.png').convert_alpha())
redbird_midflap = pygame.transform.scale2x(pygame.image.load('assets/redbird-midflap.png').convert_alpha())
redbird_upflap = pygame.transform.scale2x(pygame.image.load('assets/redbird-upflap.png').convert_alpha())
redbird_frames = [redbird_downflap,redbird_midflap,redbird_upflap]

#blue bird
yellowbird_downflap = pygame.transform.scale2x(pygame.image.load('assets/yellowbird-downflap.png').convert_alpha())
yellowbird_midflap = pygame.transform.scale2x(pygame.image.load('assets/yellowbird-midflap.png').convert_alpha())
yellowbird_upflap = pygame.transform.scale2x(pygame.image.load('assets/yellowbird-upflap.png').convert_alpha())
yellowbird_frames = [yellowbird_downflap,yellowbird_midflap,yellowbird_upflap]

#define global variable
clicked = False

class button():
		
	#colours for button and text
	button_col = (160,160,160)
	hover_col = (75, 225, 255)
	click_col = (75, 75, 75)
	text_col = black
	width = 180
	height = 70

	def __init__(self, x, y, text):
		self.x = x
		self.y = y
		self.text = text

	def draw_button(self):

		global clicked
		action = False

		#get mouse position
		pos = pygame.mouse.get_pos()

		#create pygame Rect object for the button
		button_rect = Rect(self.x, self.y, self.width, self.height)
		
		#check mouseover and clicked conditions
		if button_rect.collidepoint(pos):
			if pygame.mouse.get_pressed()[0] == 1:
				clicked = True
				pygame.draw.rect(screen, self.click_col, button_rect)
			elif pygame.mouse.get_pressed()[0] == 0 and clicked == True:
				clicked = False
				action = True
			else:
				pygame.draw.rect(screen, self.hover_col, button_rect)
		else:
			pygame.draw.rect(screen, self.button_col, button_rect)
		
		#add shading to button
		pygame.draw.line(screen, white, (self.x, self.y), (self.x + self.width, self.y), 2)
		pygame.draw.line(screen, white, (self.x, self.y), (self.x, self.y + self.height), 2)
		pygame.draw.line(screen, black, (self.x, self.y + self.height), (self.x + self.width, self.y + self.height), 2)
		pygame.draw.line(screen, black, (self.x + self.width, self.y), (self.x + self.width, self.y + self.height), 2)

		#add text to button
		text_img = font.render(self.text, True, self.text_col)
		text_len = text_img.get_width()
		screen.blit(text_img, (self.x + int(self.width / 2) - int(text_len / 2), self.y + 25))
		return action



red = button(125, 200, 'RED')
blue = button(400, 200, 'BLUE')
yellow = button(675, 200, 'YELLOW')
Exit = button(400, 350,'EXIT')


run = True
while run:

	screen.blit(bg,(0,0))

	if red.draw_button():
		main_game(redbird_frames)
	if blue.draw_button():
		main_game(bluebird_frames)
	if yellow.draw_button():
		main_game(yellowbird_frames)
	if Exit.draw_button():
		sys.exit()

	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run = False	

	pygame.display.update()


pygame.quit()